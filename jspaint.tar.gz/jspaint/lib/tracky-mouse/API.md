# API docs have moved

The API documentation has moved to the [core/README.md](./core/README.md) file.
