export function hello() {
	console.log("hello from the server's shared folder");
}
